<?php
    include "conecta.php";
    $mysqli = conexa("criador","criador");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastra Pais</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body class="bg-dark text-white text-center">
<div class="container">
        <div class="row mt-5">
            <a class="btn btn-primary col-1 fs-5" href="mostpais.php">Mostrar Pais</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-success col-1 fs-5" href="cadpais.php">Cadastrar Pais</a>
            <div class="bg-dark col-2"></div>
            <a class="btn btn-info col-2 fs-1" href="/familia">Início</a>
            <div class="bg-dark col-2"></div>
            <a class="btn btn-warning col-1 fs-5" href="altpais.php">Alterar Pais</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-danger col-1 fs-5" href="excpais.php">Excluir Pais</a>
        </div>
        <div class="row mt-5">
            <a class="btn btn-primary col-1 fs-5" href="mostfilhos.php">Mostrar Filhos</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-success col-1 fs-5" href="cadfilhos.php">Cadastrar Filhos</a>

            <div class="bg-dark col-6 fs-1">Família</div>

            <a class="btn btn-warning col-1 fs-5" href="altfilhos.php">Alterar Filhos</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-danger col-1 fs-5" href="excfilhos.php">Excluir Filhos</a>
        </div>
        <div class="row mt-5">

            <form action="cadfilhos.php" method="POST">
                <div class="row">
                    <label for="nome" class="col-2 offset-3">Nome:</label>
                    <input type="text" name="nome" placeholder="Nome do novo filho" class="col-2 rounded-4">
                </div>
                <div class="row">
                    <label for="nome" class="col-2 offset-3">Pai:</label>
                    <input type="number" name="papi" placeholder="Id do papai" class="col-2 rounded-4">
                </div>
                <div class="row mt-1">
                    <button type="submit" class="btn btn-primary fw-bold col-2 offset-5 fs-6">Incluir</button>
                </div>
            </form>    
            <?php
                if(empty($_POST["nome"])){
                    echo "<p class='text-danger'>Preencha todos os campos corretamente</p>";
                    exit;
                } else {
                    $nome = $_POST["nome"];
                    $papi = $_POST["papi"];
                    $query = "call criafilho('$nome',$papi)"; //O usuário criador só tem permissão para executar o procedure criafilho, nada mais.
                if(mysqli_query($mysqli, $query)){
                    echo "<p class='text-success'>Os dados foram inseridos corretamente. Verifique o resultado na aba Exibir.</p>";
                } else{
                    echo "<p class='text-danger'>Houve um erro.</p><p>Nenhum dado foi inserido.</p>".mysqli_error($mysqli);
                }
                }
                mysqli_close($mysqli);
            ?>

        </div>
    </div>
</body>
</html>
<?php
    include "conecta.php";
    $mysqli = conexa("mostrador","mostrador");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostra Filhos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body class="bg-dark text-white text-center">
<div class="container">
        <div class="row mt-5">
            <a class="btn btn-primary col-1 fs-5" href="mostpais.php">Mostrar Pais</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-success col-1 fs-5" href="cadpais.php">Cadastrar Pais</a>
            <div class="bg-dark col-2"></div>
            <a class="btn btn-info col-2 fs-1" href="/familia">Início</a>
            <div class="bg-dark col-2"></div>
            <a class="btn btn-warning col-1 fs-5" href="altpais.php">Alterar Pais</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-danger col-1 fs-5" href="excpais.php">Excluir Pais</a>
        </div>
        <div class="row mt-5">
            <a class="btn btn-primary col-1 fs-5" href="mostfilhos.php">Mostrar Filhos</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-success col-1 fs-5" href="cadfilhos.php">Cadastrar Filhos</a>

            <div class="bg-dark col-6 fs-1">Família</div>

            <a class="btn btn-warning col-1 fs-5" href="altfilhos.php">Alterar Filhos</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-danger col-1 fs-5" href="excfilhos.php">Excluir Filhos</a>
        </div>
        <table class="table table-dark mt-5">
            <thead>
                <tr>
                    <th class="col-1">Id</th>
                    <th class="col-2">Filho</th>
                    <th class="col-2">Pai</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $result = $mysqli->query("call finnerp()");
                    while ($query = $result->fetch_assoc())
                    {
                        echo "<tr>";
                        echo " <td class='col-1'>".$query["filho_id"]."</td>";
                        echo "<td class='col-2'>".$query["filho_nome"]."</td>";
                        echo "<td class='col-2'>".$query["pai_nome"]."</td>";
                        echo "</tr>";
                    }
                    mysqli_close($mysqli);
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
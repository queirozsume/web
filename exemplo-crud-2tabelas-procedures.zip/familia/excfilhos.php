<?php
    include "conecta.php";
    $mysqli = conexa("destruidor","destruidor");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exclui Pais</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body class="bg-dark text-white text-center">
<div class="container">
        <div class="row mt-5">
            <a class="btn btn-primary col-1 fs-5" href="mostpais.php">Mostrar Pais</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-success col-1 fs-5" href="cadpais.php">Cadastrar Pais</a>
            <div class="bg-dark col-2"></div>
            <a class="btn btn-info col-2 fs-1" href="/familia">Início</a>
            <div class="bg-dark col-2"></div>
            <a class="btn btn-warning col-1 fs-5" href="altpais.php">Alterar Pais</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-danger col-1 fs-5" href="excpais.php">Excluir Pais</a>
        </div>
        <div class="row mt-5">
            <a class="btn btn-primary col-1 fs-5" href="mostfilhos.php">Mostrar Filhos</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-success col-1 fs-5" href="cadfilhos.php">Cadastrar Filhos</a>

            <div class="bg-dark col-6 fs-1">Família</div>

            <a class="btn btn-warning col-1 fs-5" href="altfilhos.php">Alterar Filhos</a>
            <div class="bg-dark col-1"></div>
            <a class="btn btn-danger col-1 fs-5" href="excfilhos.php">Excluir Filhos</a>
        </div>
        <div class="row mt-5">
            <table class="table col-sm-12 table-dark">
            <thead>
            <tr>
            <th class="col-sm-3">ID</th>
            <th class="col-sm-2">Nome</th>
            <th class="col-sm-2">Pai</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $result = $mysqli->query("call mostrafilhos()");
            while ($query = $result->fetch_assoc())
            {
            echo "
            <tr>
            <td>
            <form action='excfilhos.php' method='post'>
            <input type='submit' value='Excluir' class='btn btn-danger' title='Excluir'/>
            <input type='number' readonly class='btn btn-warning' name='id' value='".$query["filho_id"]."' readonly/>
            </form>
            </td>
            <td>".$query["filho_nome"]."</td>
            <td>".$query["pai"]."</td>
            </tr>
            ";
            }
            //----------------------------------------------------------------------------------------
            mysqli_close($mysqli);
            $mysqli = conexa("destruidor","destruidor");
            //----------------------------------------------------------------------------------------
            if(isset($_POST["id"])){
            $id = $_POST["id"];
            $query = "call excluifilho($id)";
            if(mysqli_query($mysqli, $query)
            && isset($_POST["id"])){
            echo "<p
            class='text-success'>Os dados
            foram excluídos corretamente.
            Verifique o resultado na aba
            Exibir.</p>";
            } else
            if(!mysqli_query($mysqli, $query) && !isset($_POST["id"])){
            echo "<p
            class='text-danger'>Houve um
            erro.</p><p>Nenhum dado foi
            excluído.</p>".mysqli_error($mysqli);
            }
            }
            mysqli_close($mysqli);
            ?>
            </tbody>
            </table>
        </div>
</div>
</body>
</html>
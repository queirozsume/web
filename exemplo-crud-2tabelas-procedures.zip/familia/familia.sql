create user 'alterador'@'localhost';
create user 'criador'@'localhost';
create user 'destruidor'@'localhost';
create user 'mostrador'@'localhost';

create database familia charset utf8 collate utf8_general_ci;

use familia;

create table pais(
    pai_id int primary key auto_increment,
    pai_nome varchar(20) not null
);

create table filhos(
    filho_id int primary key auto_increment,
    filho_nome varchar(20) not null,
    pai int,
    constraint fk_pai foreign key(pai) references pais(pai_id)
    on update cascade on delete set null  
);

insert into pais(pai_nome)values("José"),("João"),("Francisco");

insert into filhos(filho_nome,pai)values("Zezinho",1),("Zefinha",1),("Joãozinho",2),
("Joaninha",2),("Chiquinho",3),("Chiquinha",3);

delimiter //

create procedure mostrapais()
begin
select * from pais;
end //

create procedure mostrafilhos()
begin
select * from filhos;
end //

create procedure finnerp()
begin
select filhos.filho_id, filhos.filho_nome, pais.pai_nome from filhos inner join pais on filhos.pai=pais.pai_id;
end //

create procedure criapai(in nome varchar(20))
begin
insert into pais(pai_nome)values(nome);
end //

create procedure criafilho(in nome varchar(20), in id int)
begin
insert into filhos(filho_nome, pai)values(nome,id);
end //

create procedure mudapai(in id int,in nome varchar(20))
begin
update pais set pai_nome=nome where pai_id=id;
end //

create procedure mudafilho(in id int, in nome varchar(20), in gen int)
begin
update filhos set filho_nome=nome, pai=gen where filho_id=id;
end //

create procedure excluipai(in id int)
begin
delete from pais where pai_id=id;
end //

create procedure excluifilho(in id int)
begin
delete from filhos where filho_id=id;
end //

delimiter ;

grant execute on procedure familia.mostrapais to 'mostrador'@'localhost';
grant execute on procedure familia.mostrafilhos to 'mostrador'@'localhost';
grant execute on procedure familia.finnerp to 'mostrador'@'localhost';

grant execute on procedure familia.criapai to 'criador'@'localhost';
grant execute on procedure familia.criafilho to 'criador'@'localhost';

grant execute on procedure familia.mostrapais to 'destruidor'@'localhost';
grant execute on procedure familia.mostrafilhos to 'destruidor'@'localhost';
grant execute on procedure familia.excluipai to 'destruidor'@'localhost';
grant execute on procedure familia.excluifilho to 'destruidor'@'localhost';

grant execute on procedure familia.mostrapais to 'alterador'@'localhost';
grant execute on procedure familia.mostrafilhos to 'alterador'@'localhost';
grant execute on procedure familia.mudapai to 'alterador'@'localhost';
grant execute on procedure familia.mudafilho to 'alterador'@'localhost';
